
let orders = [];
let purchases = [];
let expenses = [];

function showPage(id) {
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
}

function login(event) {
    event.preventDefault();
    alert("تم تسجيل الدخول بنجاح!");
}

function saveSettings(event) {
    event.preventDefault();
    const shopName = document.getElementById('shop-name').value;
    const shopLogo = document.getElementById('shop-logo').value;
    const currency = document.getElementById('currency').value;
    const language = document.getElementById('language').value;

    alert("تم حفظ الإعدادات بنجاح!");
    console.log(shopName, shopLogo, currency, language);
}
